# key - value
access = [
    ('0', 'Profesor'),
    ('1', 'Jefe de Departamento'),
    ('2', 'Subdirector'),
    ('3', 'Gestión Tecnológica'),
    ('4', 'Administrador')
]

department = [
    ('0', 'Ninguno'),
    ('1', 'Informática'),
    ('2', 'Diseño Industrial'),
    ('3', 'Administración'),
    ('4', 'Arquitectura'),
    ('5', 'Gestión Empresarial'),
    ('6', 'Industrial'),
    ('7', 'Sistemas Computacionales')
]



