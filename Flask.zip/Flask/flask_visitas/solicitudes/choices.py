from flask_visitas.usuarios.models import User

periodo = [
    ('0', 'Enero - Junio'),
    ('1', 'Agosto - Diciembre')
]

turno = [
    ('0', 'Matutino'),
    ('1', 'Vespertino')
]

carrera = [
    ('0', 'Ing. Informática'),
    ('1', 'Ing. en Diseño Industrial'),
    ('2', 'Lic. en Administración'),
    ('3', 'Arquitectura'),
    ('4', 'Ing. en Gestión Empresarial'),
    ('5', 'Ing. Industrial'),
    ('6', 'Ing. en Sistemas Computacionales'),
]

status = [
    ('0', 'Espera'),
    ('1', 'Aceptado'),
    ('2', 'Rechazado')
]

department = [
    ('0', 'Ninguno'),
    ('1', 'Informática'),
    ('2', 'Diseño Industrial'),
    ('3', 'Administración'),
    ('4', 'Arquitectura'),
    ('5', 'Gestión Empresarial'),
    ('6', 'Industrial'),
    ('7', 'Sistemas Computacionales')
]




